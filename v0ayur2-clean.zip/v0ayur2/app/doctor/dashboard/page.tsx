"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import NavBar from "@/app/components/nav-bar"
import Sidebar from "@/app/components/sidebar"
import { Button } from "@/components/ui/button"
import apiClient from "@/lib/api-client"
import { toast } from "react-toastify"
import { formatDateTime } from "@/lib/utils"

const SIDEBAR_LINKS = [
  { label: "Dashboard", href: "/doctor/dashboard", icon: "🏠" },
  { label: "My Appointments", href: "/doctor/appointments", icon: "📅" },
  { label: "Patients", href: "/doctor/patients", icon: "👥" },
  { label: "Schedule", href: "/doctor/schedule", icon: "⏰" },
  { label: "Profile", href: "/doctor/profile", icon: "👤" },
]

interface Appointment {
  appointmentId: number
  apptDate: string
  status: string
  reason: string
  patientName: string
  patientEmail: string
}

export default function DoctorDashboard() {
  const router = useRouter()
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [stats, setStats] = useState({ total: 0, scheduled: 0, completed: 0 })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem("token")
    const user = localStorage.getItem("user")

    if (!token || !user) {
      router.push("/login")
      return
    }

    fetchAppointments()
  }, [router])

  const fetchAppointments = async () => {
    try {
      const user = JSON.parse(localStorage.getItem("user") || "{}")
      const response = await apiClient.get(`/doctor/${user.doctorId}/appointments`)
      const appointments = response.data.appointments || []
      setAppointments(appointments.slice(0, 5))

      const scheduled = appointments.filter((a: Appointment) => a.status === "SCHEDULED").length
      const completed = appointments.filter((a: Appointment) => a.status === "COMPLETED").length

      setStats({
        total: appointments.length,
        scheduled,
        completed,
      })
    } catch (error: any) {
      console.error("[v0] Fetch error:", error)
      toast.error("Failed to load appointments")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <NavBar />

      <div className="flex">
        <Sidebar links={SIDEBAR_LINKS} />

        <main className="flex-1 p-8 animate-fade-in">
          <div className="max-w-6xl mx-auto space-y-8">
            <div>
              <h1 className="text-4xl font-bold text-slate-900">Doctor Dashboard</h1>
              <p className="text-slate-600 mt-2">Manage your appointments and patients</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md gradient-card">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-600 text-sm font-medium">Total Appointments</p>
                    <p className="text-3xl font-bold text-blue-600 mt-2">{stats.total}</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-xl">📅</div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md gradient-card">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-600 text-sm font-medium">Scheduled</p>
                    <p className="text-3xl font-bold text-amber-600 mt-2">{stats.scheduled}</p>
                  </div>
                  <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center text-xl">⏳</div>
                </div>
              </div>

              <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md gradient-card">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-slate-600 text-sm font-medium">Completed</p>
                    <p className="text-3xl font-bold text-emerald-600 mt-2">{stats.completed}</p>
                  </div>
                  <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center text-xl">✅</div>
                </div>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 animate-slide-in">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-slate-900">Upcoming Appointments</h2>
                <Button
                  onClick={() => router.push("/doctor/appointments")}
                  className="text-blue-600 hover:text-blue-700 bg-transparent border-slate-300 rounded-lg"
                  variant="outline"
                >
                  View All
                </Button>
              </div>

              {loading ? (
                <div className="text-center py-8">
                  <p className="text-slate-500">Loading appointments...</p>
                </div>
              ) : appointments.filter((a) => a.status === "SCHEDULED").length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-slate-500">No upcoming appointments</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {appointments
                    .filter((a) => a.status === "SCHEDULED")
                    .map((appointment) => (
                      <div
                        key={appointment.appointmentId}
                        className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-xl hover:shadow-md transition-all duration-300"
                      >
                        <div className="flex-1">
                          <p className="font-semibold text-slate-900">{appointment.patientName}</p>
                          <p className="text-sm text-slate-600">{appointment.patientEmail}</p>
                          <p className="text-sm text-slate-500 mt-1">{formatDateTime(appointment.apptDate)}</p>
                        </div>
                        <Button
                          onClick={() => router.push(`/doctor/appointments`)}
                          className="bg-blue-600 hover:bg-blue-700 text-white rounded-lg"
                        >
                          View
                        </Button>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
